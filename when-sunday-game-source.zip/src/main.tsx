import { useRef, useState } from 'react'
import { createRoot } from 'react-dom/client'
import { scenes } from './scenes'
import './style.css'

type Character = 'Boy' | 'Girl'
const chapters = [
  { name: 'Morning', icon: '☀️', copy: 'Open the curtains, make breakfast, and get ready for the day.', color: 'morning' },
  { name: 'Afternoon', icon: '🏀', copy: 'Help out at home and get moving at the basketball court.', color: 'afternoon' },
  { name: 'Evening', icon: '🌙', copy: 'Settle in for dinner and get ready for a good night’s sleep.', color: 'evening' },
]

function App() {
  const [page, setPage] = useState<'setup' | 'chapters' | 'play' | 'results'>('setup')
  const [character, setCharacter] = useState<Character>()
  const [name, setName] = useState('')
  const [chapter, setChapter] = useState(0)
  const [sceneIndex, setScene] = useState(0)
  const [stepIndex, setStep] = useState(0)
  const [hearts, setHearts] = useState(3)
  const [right, setRight] = useState(0)
  const [wrong, setWrong] = useState(0)
  const [picked, setPicked] = useState<string[]>([])
  const [feedback, setFeedback] = useState('')
  const track = useRef<HTMLDivElement>(null)
  const heading = useRef<HTMLHeadingElement>(null)
  const scene = scenes[sceneIndex]
  const step = scene.steps[stepIndex]
  const ordered = sceneIndex === 5 && stepIndex === 0
  const multiple = (step.correct?.length ?? 0) > 1

  function show(next: typeof page) {
    setPage(next)
    requestAnimationFrame(() => heading.current?.focus())
  }

  function startMorning() {
    setScene(0)
    setStep(0)
    setHearts(3)
    setRight(0)
    setWrong(0)
    setPicked([])
    setFeedback('')
    show('play')
  }

  function advance() {
    setPicked([])
    setFeedback('')
    if (stepIndex + 1 < scene.steps.length) {
      setStep(stepIndex + 1)
    } else if (sceneIndex + 1 < scenes.length) {
      setScene(sceneIndex + 1)
      setStep(0)
      setHearts(3)
      heading.current?.focus()
    } else {
      show('results')
    }
  }

  function submit(answers: string[]) {
    if (!step.correct) {
      advance()
      return
    }
    const correct = answers.length === step.correct.length &&
      step.correct.every((answer, index) => ordered ? answers[index] === answer : answers.includes(answer))
    if (correct) {
      setRight(right + 1)
      advance()
      return
    }
    setWrong(wrong + 1)
    setPicked([])
    if (hearts === 1) {
      setHearts(3)
      setStep(0)
      setFeedback('Three fresh hearts. Try this scene again! ' + step.hint)
    } else {
      setHearts(hearts - 1)
      setFeedback(step.hint ?? 'Try again.')
    }
  }

  function browse(index: number) {
    const next = Math.min(2, Math.max(0, index))
    const panel = track.current?.children[next]
    if (panel instanceof HTMLElement) track.current?.scrollTo({ left: panel.offsetLeft })
    setChapter(next)
  }

  function showChapters() {
    setChapter(0)
    show('chapters')
  }

  const total = right + wrong
  const correctPercent = total ? Math.round(right / total * 100) : 0

  return <main className="shell mx-auto max-w-6xl px-5 pb-12">
    <header className="masthead flex items-center justify-between gap-4">
      <span className="brand"><span aria-hidden="true">☼</span> When Sunday Comes Around</span>
      {page === 'chapters' && <button className="secondary" onClick={() => show('setup')}>Change player</button>}
    </header>
    {page === 'setup' && <section className="setup">
      <div className="intro">
        <h1 ref={heading} tabIndex={-1}>A day of<br />healthy habits.</h1>
        <p>Pick a character to spend Sunday with.</p>
      </div>
      <form className="paper p-5 sm:p-8" onSubmit={event => { event.preventDefault(); if (character && name.trim()) showChapters() }}>
        <fieldset>
          <legend>Choose your character</legend>
          <div className="grid grid-cols-2 gap-3">
            {(['Boy', 'Girl'] as const).map(option => <button className="character" type="button" key={option} aria-pressed={character === option} onClick={() => setCharacter(option)}>
              <span aria-hidden="true">{option === 'Boy' ? '👦🏻' : '👧🏻'}</span>{option}
            </button>)}
          </div>
        </fieldset>
        <label className="mt-6 block" htmlFor="nickname">What should we call you?</label>
        <input id="nickname" value={name} maxLength={24} onChange={event => setName(event.target.value)} placeholder="Your nickname" />
        <div className="mt-5 flex flex-wrap gap-3">
          <button disabled={!character || !name.trim()}>Start my Sunday</button>
          <button className="secondary" type="button" disabled={!character} onClick={() => { setName(''); showChapters() }}>Play as guest</button>
        </div>
      </form>
    </section>}
    {page === 'chapters' && <section>
      <div className="chapter-heading">
        <h1 ref={heading} tabIndex={-1}>{name.trim() ? name.trim() + '’s Sunday' : 'Your Sunday'}</h1>
        <p>Swipe or use the arrows to explore the day.</p>
      </div>
      <div className="track" ref={track} tabIndex={0} aria-label="Sunday chapters"
        onKeyDown={event => {
          if (event.key === 'ArrowRight' || event.key === 'ArrowLeft') {
            event.preventDefault()
            browse(chapter + (event.key === 'ArrowRight' ? 1 : -1))
          }
        }}
        onScroll={event => {
          const element = event.currentTarget
          const nearest = Array.from(element.children).reduce((best, child, index) =>
            Math.abs((child as HTMLElement).offsetLeft - element.scrollLeft) <
            Math.abs((element.children[best] as HTMLElement).offsetLeft - element.scrollLeft) ? index : best, 0)
          setChapter(nearest)
        }}>
        {chapters.map((item, index) => <article className="chapter" key={item.name}>
          <div className="paper chapter-text">
            <h2>{item.name}</h2><p>{item.copy}</p>
            <button disabled={index !== 0} onClick={startMorning}>{index === 0 ? 'Play Morning' : 'Coming soon'}</button>
          </div>
          <div className={'portrait ' + item.color} aria-hidden="true"><span>{item.icon}</span><strong>{character === 'Boy' ? '👦🏻' : '👧🏻'}</strong></div>
        </article>)}
      </div>
      <nav className="mt-5 flex flex-wrap items-center justify-between gap-3" aria-label="Browse chapters">
        <button className="secondary" disabled={chapter === 0} onClick={() => browse(chapter - 1)}>← Previous</button>
        <span aria-live="polite">{chapters[chapter].name} · {chapter + 1} of 3</span>
        <button className="secondary" disabled={chapter === 2} onClick={() => browse(chapter + 1)}>Next →</button>
      </nav>
    </section>}
    {page === 'play' && <section className="play">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <span>Morning · Scene {sceneIndex + 1} of {scenes.length}</span>
        {scene.steps.some(item => item.correct) && <span className="hearts" aria-label={hearts + ' of 3 hearts'}>{'♥'.repeat(hearts)}{'♡'.repeat(3 - hearts)}</span>}
      </div>
      <progress aria-label="Morning progress" value={sceneIndex} max={scenes.length} />
      <div className="paper activity">
        <div className="scene-icon" aria-hidden="true">{character === 'Boy' ? '👦🏻' : '👧🏻'} {scene.icon}</div>
        <h1 ref={heading} tabIndex={-1}>{scene.title}</h1>
        <p>{step.text}</p>
        <div className="options">
          {step.options.map(option => <button key={option} className="secondary" aria-pressed={multiple ? picked.includes(option) : undefined} onClick={() => {
            if (!multiple) { submit([option]); return }
            setPicked(picked.includes(option) ? picked.filter(value => value !== option) : [...picked, option])
          }}>{ordered && picked.includes(option) ? (picked.indexOf(option) + 1) + '. ' : ''}{option}</button>)}
        </div>
        {multiple && <button className="mt-4" disabled={picked.length === 0} onClick={() => submit(picked)}>Check answer</button>}
        <div className="mt-4" role="status">{feedback}</div>
      </div>
    </section>}
    {page === 'results' && <section className="paper activity results">
      <div className="scene-icon" aria-hidden="true">☀️</div>
      <h1 ref={heading} tabIndex={-1}>Morning complete!</h1>
      {total ? <div className="scores grid grid-cols-2 gap-3">
        <div><strong>{correctPercent}%</strong><span>{right} correct</span></div>
        <div><strong>{100 - correctPercent}%</strong><span>{wrong} incorrect</span></div>
      </div> : <p>No scored answers yet.</p>}
      <p>Afternoon and Evening are coming soon.</p>
      <div className="flex flex-wrap gap-3"><button onClick={startMorning}>Replay Morning</button><button className="secondary" onClick={showChapters}>Back to chapters</button></div>
    </section>}
  </main>
}

createRoot(document.getElementById('root')!).render(<App />)
