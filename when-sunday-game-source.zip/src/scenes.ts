export type Step = {
  text: string
  options: string[]
  correct?: string[]
  hint?: string
}

export const scenes: { title: string; icon: string; steps: Step[] }[] = [
  { title: 'Rise and shine', icon: '⏰', steps: [
    { text: 'The alarm rings. You sit up, pull the blanket straight, and fluff your pillow.', options: ['Continue', 'Skip scene'] },
  ] },
  { title: 'Let the light in', icon: '☀️', steps: [
    { text: 'How can you make your room brighter?', options: ['Close the door', 'Open the curtains', 'Hide under the blanket'], correct: ['Open the curtains'], hint: 'The curtains are blocking the daylight.' },
    { text: 'Pick a gentle stretch. You can try it seated or standing on a clear floor.', options: ['Roll my shoulders', 'Reach overhead'] },
  ] },
  { title: 'Wash your face', icon: '💧', steps: [
    { text: 'Your face feels sleepy. What could help?', options: ['Turn on the TV', 'Put on my shoes', 'Wash my face'], correct: ['Wash my face'], hint: 'Think about what you can do at the sink.' },
    { text: 'Start with clean water.', options: ['Wet my face'] },
    { text: 'Wash gently, then rinse with clean water.', options: ['Wash and rinse'] },
    { text: 'Use a clean towel to pat your face dry.', options: ['Pat dry'] },
  ] },
  { title: 'Breakfast time', icon: '🍳', steps: [
    { text: 'Before breakfast, wash your hands with soap and water.', options: ['Wash my hands'] },
    { text: 'Choose both Go foods. Go foods give you energy.', options: ['Pandesal', 'Egg', 'Banana', 'Kamote', 'Candy'], correct: ['Pandesal', 'Kamote'], hint: 'Look for bread and a starchy root crop.' },
    { text: 'Breakfast is ready: pandesal for Go, egg for Grow, banana for Glow, and a glass of water.', options: ['Finish breakfast'] },
  ] },
  { title: 'Brush your teeth', icon: '🪥', steps: [
    { text: 'At the sink, use a soft brush and a pea-sized amount of fluoride toothpaste. Gently brush along the gum line. Clean the outside, inside, and chewing surfaces for about two minutes. Hold the brush upright behind the front teeth. Gently brush your tongue if comfortable, then spit without rinsing right away.', options: ['Choose a brushing routine'] },
    { text: 'Which routine cleans all the tooth surfaces?', options: ['Brush the front only, then spit', 'Brush the outside, inside, and chewing surfaces, then spit', 'Brush the chewing surfaces only, then spit'], correct: ['Brush the outside, inside, and chewing surfaces, then spit'], hint: 'Look for the routine that reaches all three surfaces.' },
  ] },
  { title: 'Bath and fresh clothes', icon: '🫧', steps: [
    { text: 'Put the bath steps in order by choosing what comes next.', options: ['Rinse and step onto a nonslip mat', 'Prepare a clean towel, clothes, soap, and shampoo', 'Pat dry, dress, and hang up the towel', 'Wet your body and hair if washing it', 'Ask a grown-up to check the water, then step in carefully', 'Wash gently and shampoo if needed'], correct: ['Prepare a clean towel, clothes, soap, and shampoo', 'Ask a grown-up to check the water, then step in carefully', 'Wet your body and hair if washing it', 'Wash gently and shampoo if needed', 'Rinse and step onto a nonslip mat', 'Pat dry, dress, and hang up the towel'], hint: 'Get ready first, then wet, wash, rinse, and dry.' },
    { text: 'You are clean and dressed in fresh clothes.', options: ['Continue'] },
  ] },
  { title: 'A quiet moment', icon: '📖', steps: [
    { text: 'You write a little in your journal, then watch TV until your family timer rings. TV time is finished. Time for a break!', options: ['See my results', 'Skip scene'] },
  ] },
]
